package ru.sbrf.school.domain;

public enum Models {
    X1(Brand.BMW),
    X3(Brand.BMW),
    X4(Brand.BMW),
    X5(Brand.BMW),
    X6(Brand.BMW),

    Q3(Brand.AUDI),
    Q5(Brand.AUDI),
    Q7(Brand.AUDI),

    ML(Brand.MERCEDES),
    GL(Brand.MERCEDES),
    E(Brand.MERCEDES),

    PATROL(Brand.NISSAN),
    JUKE(Brand.NISSAN),
    PATHFINDER(Brand.NISSAN),

    LAND_CRUSER_PRADO(Brand.TOYOTA),
    LAND_CRUSER(Brand.TOYOTA),
    HIGHLANDER(Brand.TOYOTA),

    TOUREG(Brand.VW),
    TIGUAN(Brand.VW),
    AMAROK(Brand.VW)
    ;

    private final Brand brand;

    Models(Brand brand) {
        this.brand = brand;
    }

    public Brand getBrand() {
        return brand;
    }
}
