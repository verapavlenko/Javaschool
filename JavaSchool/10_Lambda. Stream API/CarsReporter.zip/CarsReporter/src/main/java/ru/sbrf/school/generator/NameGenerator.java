package ru.sbrf.school.generator;

import ru.sbrf.school.domain.SellerType;
import ru.sbrf.school.domain.Sellers;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class NameGenerator {
    private final Random r = new Random();

    public String nextName(boolean isLegal) {
        List<Sellers> availableSellers = Arrays.stream(Sellers.values())
                .filter(s -> isLegal ? s.getType() == SellerType.LEGAL : s.getType() != SellerType.LEGAL)
                .collect(Collectors.toList());

        return availableSellers.get(r.nextInt(availableSellers.size())).name();
    }
}
