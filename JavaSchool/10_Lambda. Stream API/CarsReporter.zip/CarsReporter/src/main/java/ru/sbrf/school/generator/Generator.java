package ru.sbrf.school.generator;


import ru.sbrf.school.ConsumerEx;
import ru.sbrf.school.domain.Brand;
import ru.sbrf.school.domain.CarDescriptor;
import ru.sbrf.school.domain.Models;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Random;
import java.util.stream.IntStream;

import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;

public class Generator {


    public static void main(String[] argv) throws IOException {

        final Path file = Paths.get("cars.db");
        Files.deleteIfExists(file);

        Random commonGenerator = new Random();
        NameGenerator nameGenerator = new NameGenerator();
        BrandGenerator brandGenerator = new BrandGenerator();
        ModelGenerator modelGenerator = new ModelGenerator();
        LocalDateGenerator localDateGenerator = new LocalDateGenerator();

        IntStream.rangeClosed(1, 1000)
                .mapToObj(i -> {
                    final boolean isLegal = commonGenerator.nextBoolean();
                            final Brand brand = brandGenerator.nextBrand();
                            final Models model = modelGenerator.nextModel(brand);

                            return CarDescriptor.of(
                                    isLegal,
                                    nameGenerator.nextName(isLegal),
                                    brand,
                                    model,
                                    localDateGenerator.nextDate(LocalDate.of(1995, 1, 1), LocalDate.of(2015, 8, 1)),
                                    commonGenerator.nextInt(5) + 1,
                                    commonGenerator.nextInt(500) + 50,
                                    commonGenerator.nextInt(800) + 100,
                                    commonGenerator.nextInt(5000000) + 300000,
                                    localDateGenerator.nextDate(LocalDate.of(2016, 1, 1), LocalDate.of(2016, 8, 1))
                            );
                        }
                ).forEach(ConsumerEx.around(c ->
                Files.write(
                        Paths.get("cars.db"),
                        c.asDbString().concat(System.lineSeparator()).getBytes(),
                        CREATE, APPEND
                )));

    }

}
