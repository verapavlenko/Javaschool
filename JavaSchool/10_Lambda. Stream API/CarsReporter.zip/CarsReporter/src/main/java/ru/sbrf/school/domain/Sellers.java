package ru.sbrf.school.domain;

public enum Sellers {

    GLASS_FISH(SellerType.LEGAL),
    RALF(SellerType.LEGAL),
    ROLF(SellerType.LEGAL),
    CTK(SellerType.LEGAL),
    ATLANT(SellerType.LEGAL),
    AKSEL(SellerType.LEGAL),

    ANDREY(SellerType.PHYSICAL),
    ALEKSEY(SellerType.PHYSICAL),
    NICOLAY(SellerType.PHYSICAL),
    MICHAIL(SellerType.PHYSICAL),
    VLADIMIR(SellerType.PHYSICAL)
    ;

    private final SellerType type;

    Sellers(SellerType type) {
        this.type = type;
    }

    public SellerType getType() {
        return type;
    }
}
