package ru.sbrf.school.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static java.lang.String.format;

public class CarDescriptor {
    private final boolean isLegal;
    private final String sellerName;
    private final Brand brand;
    private final Models model;
    private final LocalDate dateOfMade;
    private final int owners;
    private final int hp;
    private final int torque;
    private final int price;
    private final LocalDate dateOfPublishing;


    private CarDescriptor(boolean isLegal, String sellerName, Brand brand,
                          Models model, LocalDate dateOfMade, int owners,
                          int hp, int torque, int price, LocalDate dateOfPublishing) {
        this.isLegal = isLegal;
        this.sellerName = sellerName;
        this.brand = brand;
        this.model = model;
        this.dateOfMade = dateOfMade;
        this.owners = owners;
        this.hp = hp;
        this.torque = torque;
        this.price = price;
        this.dateOfPublishing = dateOfPublishing;
    }

    public static CarDescriptor ofString(String descr) {
        String[] values = descr.split(";");

        return new CarDescriptor(
                values[0].equalsIgnoreCase("legal"),
                values[1],
                Brand.valueOf(values[2]),
                Models.valueOf(values[3]),
                LocalDate.of(Integer.parseInt(values[4]), 1, 1),
                Integer.parseInt(values[5]),
                Integer.parseInt(values[6]),
                Integer.parseInt(values[7]),
                Integer.parseInt(values[8]),
                LocalDate.parse(values[9], DateTimeFormatter.ISO_LOCAL_DATE)
        );
    }

    public static CarDescriptor of(boolean isLegal, String sellerName, Brand brand,
                                   Models model, LocalDate dateOfMade, int owners,
                                   int hp, int torque, int price, LocalDate dateOfPublishing) {
        return new CarDescriptor(
                isLegal,
                sellerName,
                brand,
                model,
                dateOfMade,
                owners,
                hp,
                torque,
                price,
                dateOfPublishing
        );
    }

    public String asDbString() {
        return format("%s;%s;%s;%s;%d;%d;%d;%d;%d;%s;",
                isLegal ? SellerType.LEGAL.name() : SellerType.PHYSICAL.name(),
                sellerName,
                brand.name(),
                model.name(),
                dateOfMade.getYear(),
                owners,
                hp,
                torque,
                price,
                DateTimeFormatter.ISO_LOCAL_DATE.format(dateOfPublishing)
        );
    }

    public LocalDate getMadeDate() {
        return dateOfMade;
    }

    public Brand getBrand() {
        return brand;
    }

    public int getPrice() {
        return price;
    }

    public boolean isLegal() {
        return isLegal;
    }

    public LocalDate getDateOfPublishing() {
        return dateOfPublishing;
    }

    public Models getModel() {
        return model;
    }

    @Override
    public String toString() {
        return "CarDescriptor{" +
                "isLegal=" + isLegal +
                ", sellerName='" + sellerName + '\'' +
                ", brand=" + brand +
                ", model=" + model +
                ", dateOfMade=" + dateOfMade +
                ", owners=" + owners +
                ", hp=" + hp +
                ", torque=" + torque +
                ", price=" + price +
                ", dateOfPublishing=" + dateOfPublishing +
                '}';
    }

}
