package ru.sbrf.school.generator;

import ru.sbrf.school.domain.Brand;

import java.util.Random;

public class BrandGenerator {

    private final Random r = new Random();

    public Brand nextBrand() {
        return Brand.values()[r.nextInt(Brand.values().length)];
    }
}
