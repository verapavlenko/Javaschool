package ru.sbrf.school.domain;

public enum Brand {
    BMW,
    AUDI,
    MERCEDES,
    NISSAN,
    TOYOTA,
    VW
    ;
}
