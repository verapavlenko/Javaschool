package ru.sbrf.school.report;

import org.apache.commons.io.FileUtils;
import ru.sbrf.school.ConsumerEx;
import ru.sbrf.school.domain.CarDescriptor;
import ru.sbrf.school.domain.Brand;
import ru.sbrf.school.domain.Models;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.lang.String.format;

public class ReportBuilder {

    // 1. Отсортировать по цене и выгрузить в файл в таком же формате
    public static void exerciseOne() throws IOException {
        final Path path = Paths.get("sortedByPrice.db");
        FileUtils.deleteQuietly(path.toFile());

        List<String> sortedByPrice = Files.lines(Paths.get("cars.db"))
                .map(CarDescriptor::ofString)
                .sorted(Comparator.comparingInt(CarDescriptor::getPrice))
                .map(CarDescriptor::asDbString)
                .collect(Collectors.toList());

        Files.write(path, sortedByPrice);
    }

    // 2. Найти самые дешевые предложения не страше 2010 года, только от юр лиц и выложит в каталог
    // cheaper по отдельным файлам с названием марки
    public static void exerciseTwo() throws IOException {
        Map<Brand, Optional<CarDescriptor>> result = Files.lines(Paths.get("cars.db"))
                .map(CarDescriptor::ofString)
                .filter(d -> d.getMadeDate().isAfter(LocalDate.of(2009, 1, 1)))
                .filter(CarDescriptor::isLegal)
                .collect(Collectors.groupingBy(
                        CarDescriptor::getBrand,
                        Collectors.minBy(Comparator.comparingInt(CarDescriptor::getPrice))
                ));

        final File outputDir = new File("cheaper");
        FileUtils.deleteQuietly(outputDir);

        result.entrySet().forEach(ConsumerEx.around(r ->
                FileUtils.writeStringToFile(
                        new File(outputDir, r.getKey().name().concat(".db")),
                        r.getValue()
                                .map(CarDescriptor::asDbString)
                                .orElseThrow(RuntimeException::new))
        ));
    }

    // 3. Выгрузить статистику по размещённым машинам самой популярной марки по месецам текущего года.
    // Если за месяц не было ни одного размещения нужно вернут 0
    // выгрузить статистику в файл publishingMostPopular2016.stat
    public static void exerciseThree() throws IOException {
        final File path = new File("publishingMostPopular2016.stat");
        FileUtils.deleteQuietly(path);

        Optional<Map.Entry<Models, List<CarDescriptor>>> topCar =
                Files.lines(Paths.get("cars.db"))
                        .map(CarDescriptor::ofString)
                        .filter(c -> c.getDateOfPublishing().isAfter(LocalDate.of(2016, 1, 1)))
                        .collect(Collectors.groupingBy(
                                CarDescriptor::getModel,
                                Collectors.toList())
                        )
                        .entrySet()
                        .stream()
                        .max(Comparator.comparingLong(e -> e.getValue().size()));


        Map<Integer, Long> stat = topCar
                .map(Map.Entry::getValue)
                .map(lst ->
                        lst.stream()
                                .collect(Collectors.groupingBy(
                                        c -> c.getDateOfPublishing().getMonthValue(),
                                        Collectors.counting())
                                )
                ).orElse(Collections.emptyMap());


        topCar.ifPresent(ConsumerEx.around(c ->
                FileUtils.writeStringToFile(path, format("============== %s =============\n", c.getKey().name())))
        );

        IntStream.rangeClosed(1, 12)
                .mapToObj(i -> Stat.of(
                        i,
                        Optional.ofNullable(stat.get(i)).orElse(0l)
                ))
                .sorted(Comparator.comparingInt(Stat::getMonth))
                .forEach(ConsumerEx.around(v ->
                        FileUtils.writeStringToFile(path, v.toString().concat(System.lineSeparator()), true))
                );
    }


    public static void main(String[] args) throws URISyntaxException, IOException {

        exerciseOne();
        exerciseTwo();
        exerciseThree();
    }

}
