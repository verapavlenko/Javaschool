package ru.sbrf.school.report;

public class Stat {
    private final int month;
    private final long amount;

    private Stat(int month, long amount) {
        this.month = month;
        this.amount = amount;
    }

    public static Stat of(int month, long amount) {
        return new Stat(month, amount);
    }

    public int getMonth() {
        return month;
    }

    public long getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return "Stat{" +
                "month=" + month +
                ", amount=" + amount +
                '}';
    }
}
