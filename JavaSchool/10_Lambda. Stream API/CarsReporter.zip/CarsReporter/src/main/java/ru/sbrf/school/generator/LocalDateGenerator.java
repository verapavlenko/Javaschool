package ru.sbrf.school.generator;

import java.time.*;
import java.util.Random;

public class LocalDateGenerator {

    private final Random r = new Random();

    public LocalDate nextDate(LocalDate min, LocalDate max) {

        long minAsNanosec = min.atStartOfDay().atOffset(ZoneOffset.UTC).toInstant().toEpochMilli();
        long maxAsNanosec = max.atStartOfDay().atOffset(ZoneOffset.UTC).toInstant().toEpochMilli();

        long resultAsNanosec = r.longs(minAsNanosec, maxAsNanosec + 1).findAny().getAsLong(); 

        return OffsetDateTime.ofInstant(Instant.ofEpochMilli(resultAsNanosec), ZoneOffset.UTC).toLocalDate();
    }
}
