package ru.sbrf.school;


import java.util.function.Consumer;

@FunctionalInterface
public interface ConsumerEx<T> {
    void consume(T t) throws Exception;

    public static <U> Consumer<U> around(ConsumerEx<U> t) {
        return u -> {
            try {
                t.consume(u);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        };
    }
}
