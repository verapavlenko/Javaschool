package ru.sbrf.school.generator;

import ru.sbrf.school.domain.Brand;
import ru.sbrf.school.domain.Models;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class ModelGenerator {
    private final Random r = new Random();

    public Models nextModel(Brand brand) {
        List<Models> availableModels = Arrays.stream(Models.values())
                .filter(m -> m.getBrand() == brand)
                .collect(Collectors.toList());

        return availableModels.get(r.nextInt(availableModels.size()));
    }
}
