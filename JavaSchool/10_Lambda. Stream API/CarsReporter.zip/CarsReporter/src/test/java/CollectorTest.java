import org.junit.Test;

import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertNull;

public class CollectorTest {

    @Test
    public void testCollectNullValueInList() {
        assertNull(
                Stream.of((String) null)
                        .collect(Collectors.toList())
                        .get(0)
        );
    }

//    @Test
//    public void testCollectNullValueInMap() {
//        assertNull(
//                Stream.of("")
//                        .collect(Collectors.toMap(s -> "", s -> null))
//                        .get(0)
//        );
//    }

    @Test
    public void testCollectNullValueInMapWithCustomCollector() {
        assertNull(
                Stream.of("")
                        .collect(
                                HashMap<String, Object>::new,
                                (m, val) -> m.put(val, null),
                                (m1, m2) -> m1.putAll(m2)
                        )
                        .get(0)
        );
    }
}
