package ru.sbrf.javacourse.buildtools;

public class ApplicationTest {

}
