package ru.sberbank.javacourse.springmvc.web.mvc;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import ru.sberbank.javacourse.springmvc.controller.UserController;
import ru.sberbank.javacourse.springmvc.controller.UserNotFoundException;
import ru.sberbank.javacourse.springmvc.entity.User;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.xpath;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

@RunWith(MockitoJUnitRunner.class)
public class UserRestControllerStandaloneTest {

    private MockMvc mockMvc;

    @Mock
    private UserController userController;

    @Before
    public void setUp() {
        mockMvc = standaloneSetup(new UserRestController(userController)).build();
    }

    @Test
    public void testGetUserOk() throws Exception {
        User user = new User();
        user.setName("Vladimir Zhilin");

        when(userController.getUser(1)).thenReturn(user);
        mockMvc.perform(get("/users/{id}", 1)
                .accept(MediaType.APPLICATION_XML))
                .andExpect(status().isOk())
                .andExpect(xpath("/User/name").string("Vladimir Zhilin"));
    }

    @Test
    public void testGetUserNotFound() throws Exception {
        when(userController.getUser(1)).thenThrow(UserNotFoundException.class);
        mockMvc.perform(get("/users/{id}", 1)
                .accept(MediaType.APPLICATION_XML))
                .andExpect(status().isNotFound());
    }

//    @Test
//    public void testAddUser() throws Exception {
//        mockMvc.perform(post("/users/{id}", 42).accept(MediaType.APPLICATION_XML));
//    }

}
