package ru.sberbank.javacourse.springmvc.web.mvc;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import ru.sberbank.javacourse.springmvc.controller.UserController;
import ru.sberbank.javacourse.springmvc.controller.UserNotFoundException;
import ru.sberbank.javacourse.springmvc.entity.User;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.xpath;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = UserRestControllerTest.WebConfig.class)
public class UserRestControllerTest {

    @Autowired
    private WebApplicationContext wac;

    private MockMvc mockMvc;

    @Autowired
    private UserController userController;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
        reset(userController);
    }

    @Test
    public void testGetUserOk() throws Exception {
        User user = new User();
        user.setName("Vladimir Zhilin");

        when(userController.getUser(1)).thenReturn(user);
        mockMvc.perform(get("/users/{id}", 1)
                .accept(MediaType.APPLICATION_XML))
                .andExpect(status().isOk())
                .andExpect(xpath("/User/name").string("Vladimir Zhilin"));
    }

    @Test
    public void testGetUserNotFound() throws Exception {
        when(userController.getUser(1)).thenThrow(UserNotFoundException.class);
        mockMvc.perform(get("/users/{id}", 1)
                .accept(MediaType.APPLICATION_XML))
                .andExpect(status().isNotFound());
    }

    @Configuration
    @ComponentScan("ru.sberbank.javacourse.springmvc.web.mvc")
    @EnableWebMvc
    public static class WebConfig {
        @Bean
        UserController userController() {
            return mock(UserController.class);
        }
    }

}
