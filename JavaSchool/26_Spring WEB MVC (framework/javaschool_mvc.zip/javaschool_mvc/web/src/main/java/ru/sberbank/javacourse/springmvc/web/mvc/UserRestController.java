package ru.sberbank.javacourse.springmvc.web.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

import ru.sberbank.javacourse.springmvc.controller.UserController;
import ru.sberbank.javacourse.springmvc.controller.UserNotFoundException;
import ru.sberbank.javacourse.springmvc.entity.User;

@RestController
@RequestMapping("/users")
public class UserRestController {

//    @ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "User not found")
//    public static class UserNotFoundException extends Exception {
//
//    }

    // Можно показать гибкость - не использовать UserRestController, а добавить аннотации к UserControllerImpl
    private UserController userController;

    @Autowired
    public UserRestController(UserController userController) {
        this.userController = userController;
    }

    @GetMapping("/{id}")
    public User getUser(@PathVariable long id) {
        //throw new UserNotFoundException();
        return userController.getUser(id);
    }

    @PostMapping
    public ResponseEntity<Void> addUser(@RequestBody User user) {
        user = userController.addUser(user);
        URI location = URI.create("/users/" + user.getId());
        return ResponseEntity.created(location).build();
    }

    @GetMapping
   // @ResponseBody
    public List<User> findUsersByNameAndAge(@RequestParam("name") String name, @RequestParam("age") int age) {
        return userController.getUsersByName(name);
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<Void> handleException(UserNotFoundException e) {
        return ResponseEntity.notFound().build();
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleException(IllegalArgumentException e) {
        return new ResponseEntity(e.getMessage(), HttpStatus.UNPROCESSABLE_ENTITY);
    }

}
