package ru.sberbank.javacourse.springmvc.web;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.sberbank.javacourse.springmvc.controller.UserController;
import ru.sberbank.javacourse.springmvc.controller.UserControllerImpl;
import ru.sberbank.javacourse.springmvc.entity.User;
import ru.sberbank.javacourse.springmvc.repository.SimpleUserRepository;
import ru.sberbank.javacourse.springmvc.repository.UserRepository;

public class UserServlet extends HttpServlet {

    private UserController userController;

    public void init(ServletConfig config) throws ServletException {
        UserRepository userRepository = new SimpleUserRepository();
        userController = new UserControllerImpl(userRepository);
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");

        ServletOutputStream outputStream = resp.getOutputStream();

        Iterable<User> users = userController.getUsersByName(name);
        for (User user : users) {
             outputStream.println(user.getName());
        }

        resp.setStatus(200);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    public void destroy() {
        userController = null;
    }

}
