package ru.sberbank.javacourse.springmvc;

public class ControllerTest {

}
