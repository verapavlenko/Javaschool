package ru.sberbank.javacourse.springmvc.repository;

import java.util.List;

import ru.sberbank.javacourse.springmvc.entity.User;

public interface UserRepository {

    User save(User user);

    User findOne(Long id);

    List<User> findByName(String name);

    void delete(Long id);

}
