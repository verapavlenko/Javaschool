package ru.sberbank.javacourse.springmvc.controller;

import java.util.List;

import ru.sberbank.javacourse.springmvc.entity.User;

public interface UserController {

    User getUser(long id);

    List<User> getUsersByName(String name);

    User addUser(User user);

    User updateUser(User user);

    void deleteUser(long id);

}
