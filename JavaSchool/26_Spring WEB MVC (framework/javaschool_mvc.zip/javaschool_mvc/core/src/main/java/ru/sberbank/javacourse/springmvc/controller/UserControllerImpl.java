package ru.sberbank.javacourse.springmvc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import ru.sberbank.javacourse.springmvc.entity.User;
import ru.sberbank.javacourse.springmvc.repository.UserRepository;

public class UserControllerImpl implements UserController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserControllerImpl.class);

    private UserRepository userRepository;

    public UserControllerImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User getUser(long id) {
        User user = userRepository.findOne(id);
        if (user == null) {
            throw new UserNotFoundException("User with id = " + id + " not found");
        }

        return user;
    }

    public List<User> getUsersByName(String name) {
        List<User> users = userRepository.findByName(name);
        LOGGER.debug("Found users by name {} {}", name, users);

        return users;
    }

    private void checkUser(User user) {
        // javax.validation

        String userName = user.getName();
        if (userName == null || userName.length() == 0) {
            throw new IllegalArgumentException("Empty name is not allowed");
        }

        if (user.getSalary() < 0) {
            throw new IllegalArgumentException("Fortunately negative salary is not allowed");
        }
    }

    private void notifyUserAdded(User user) {
        LOGGER.debug("User added {}", user);
    }

    public User addUser(User user) {
        if (user == null) {
            throw new NullPointerException();
        }
        if (user.getId() != null) {
            throw new IllegalArgumentException("You are not allowed to specify id manually");
        }
        checkUser(user);

        User added = userRepository.save(user);

        notifyUserAdded(user);

        return user;
    }

    public User updateUser(User user) {
        if (user == null) {
            throw new NullPointerException();
        }
        if (user.getId() == null) {
            throw new IllegalArgumentException("Unknown user");
        }
        checkUser(user);

        userRepository.save(user);

        return null;
    }

    public void deleteUser(long id) {
        userRepository.delete(id);
    }

}
