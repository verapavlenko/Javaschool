package ru.sberbank.javacourse.springmvc.repository;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

import ru.sberbank.javacourse.springmvc.entity.User;

public class SimpleUserRepository implements UserRepository {

    private static final AtomicLong idSequence = new AtomicLong(0);

    private static final Map<Long, User> users = new ConcurrentHashMap<>();

    // Test data
    static {
        User ivanov = new User();
        ivanov.setId(idSequence.incrementAndGet());
        ivanov.setName("Ivanov");

        User semenov = new User();
        semenov.setId(idSequence.incrementAndGet());
        semenov.setName("Semenov");

        User sergeev = new User();
        sergeev.setId(idSequence.incrementAndGet());
        sergeev.setName("Sergeev");

        Arrays.asList(ivanov, semenov, sergeev).stream()
                .forEach((user) -> users.put(user.getId(), user));
    }

    public User save(User user) {
        Long id = user.getId();
        if (id == null) {
            id = idSequence.incrementAndGet();
            user.setId(id);
        }

        users.put(id, user);

        return user;
    }

    public User findOne(Long id) {
        return users.get(id);
    }

    public List<User> findByName(String name) {
        if (name == null) {
            throw new NullPointerException();
        }

        return users.values().stream()
                .filter(user -> user.getName().startsWith(name))
                .collect(Collectors.toList());
    }

    public void delete(Long id) {
        users.remove(id);
    }
}
